const formatUrlError =
  'plz the format url is ,api/resize?file_name={{file_name:string}}&width={{width:number}}&height={{height:number}},';

export { formatUrlError };
